text=input("Enter a title:")
print("The length is: ", len(text))